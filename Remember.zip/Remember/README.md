
This is an offline App where you set your important works and it will remind you at the set time and date via a notification.<br>
This app uses Material Design components and follows MVC architecture.<br>
For database requirement, I'm using Realm.
<br><br>

<b>This is how it looks</b>

<br>
![Screenshot 1](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/Main.png "") 
![Screenshot 2](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/second.png "")
![Screenshot 3](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/time.png "")

<br>

![Screenshot 4](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/text2speech.png "")
![Screenshot 5](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/date.png "")
![Screenshot 6](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/notify.png "")

<br>

![Screenshot 7](https://github.com/Asutosh11/RemindMeAt---Android-Reminder-App/blob/master/Screenshots/reminder-msg.png "")
